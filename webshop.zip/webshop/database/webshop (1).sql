-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Máy chủ: 127.0.0.1
-- Thời gian đã tạo: Th5 04, 2021 lúc 04:57 AM
-- Phiên bản máy phục vụ: 10.4.17-MariaDB
-- Phiên bản PHP: 8.0.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Cơ sở dữ liệu: `webshop`
--

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `level` int(11) NOT NULL,
  `created` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `admin`
--

INSERT INTO `admin` (`id`, `name`, `email`, `password`, `level`, `created`) VALUES
(1, 'Goo', 'admin@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', 0, 2147483647),
(2, 'Mod đz', 'mod@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', 1, 2147483647);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `catalog`
--

CREATE TABLE `catalog` (
  `id` int(11) NOT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `parent_id` int(11) NOT NULL,
  `sort_order` tinyint(4) NOT NULL,
  `created` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `catalog`
--

INSERT INTO `catalog` (`id`, `name`, `description`, `parent_id`, `sort_order`, `created`) VALUES
(1, 'Thời trang', '', 0, 1, '2017-04-22 05:35:21'),
(2, 'Bán chạy', '', 0, 2, '2017-04-22 05:35:48'),
(3, 'Khuyến mại', '', 0, 3, '2017-04-22 05:35:59'),
(4, 'Tin tức', '', 0, 4, '2017-04-22 05:36:13'),
(5, 'Giỏ hàng', '', 0, 6, '2017-04-22 05:36:49'),
(6, 'Liên hệ', '', 0, 5, '2017-04-22 05:37:02'),
(7, 'Thời trang nam', '', 1, 1, '2017-04-22 05:37:23'),
(8, 'Thời trang nữ', '', 1, 2, '2017-04-22 05:37:36'),
(25, 'Áo khoác', '', 7, 6, '0000-00-00 00:00:00'),
(10, 'Áo phông nam', '', 7, 1, '2017-04-22 09:08:19'),
(11, 'Áo sơ mi nam', '', 7, 2, '2017-04-22 09:08:36'),
(27, 'Áo khoác', '', 8, 1, '0000-00-00 00:00:00'),
(26, 'Quần dài', '', 7, 5, '0000-00-00 00:00:00'),
(14, 'Quần Short', '', 7, 5, '2017-04-22 09:09:31'),
(28, 'Áo phông ', '', 8, 2, '0000-00-00 00:00:00'),
(29, 'Chân váy', '', 8, 3, '0000-00-00 00:00:00'),
(30, 'Quần ', '', 8, 4, '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `order`
--

CREATE TABLE `order` (
  `id` int(11) NOT NULL,
  `transaction_id` int(100) NOT NULL,
  `product_id` int(100) NOT NULL,
  `qty` int(100) NOT NULL DEFAULT 0,
  `amount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `status` int(11) NOT NULL DEFAULT 0
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `order`
--

INSERT INTO `order` (`id`, `transaction_id`, `product_id`, `qty`, `amount`, `status`) VALUES
(1, 3, 12, 1, '360000.00', 0),
(3, 4, 7, 1, '350000.00', 0),
(12, 9, 4, 1, '200000.00', 0),
(13, 10, 17, 1, '450000.00', 0),
(6, 5, 23, 1, '370000.00', 0),
(7, 6, 28, 1, '169000.00', 0),
(8, 6, 25, 1, '300000.00', 0),
(11, 8, 10, 1, '69000.00', 0),
(10, 7, 11, 1, '70000.00', 0),
(14, 11, 25, 1, '300000.00', 0),
(15, 12, 28, 1, '169000.00', 0),
(16, 13, 55, 1, '250000.00', 0);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `product`
--

CREATE TABLE `product` (
  `id` int(255) NOT NULL,
  `catalog_id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `content` text COLLATE utf8_unicode_ci NOT NULL,
  `price` decimal(15,2) NOT NULL DEFAULT 0.00,
  `discount` int(11) DEFAULT 0,
  `image_link` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `image_list` text COLLATE utf8_unicode_ci NOT NULL,
  `view` int(11) NOT NULL DEFAULT 0,
  `buyed` int(255) NOT NULL,
  `rate_total` int(255) NOT NULL DEFAULT 4,
  `rate_count` int(255) NOT NULL DEFAULT 1,
  `created` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `product`
--

INSERT INTO `product` (`id`, `catalog_id`, `name`, `content`, `price`, `discount`, `image_link`, `image_list`, `view`, `buyed`, `rate_total`, `rate_count`, `created`) VALUES
(49, 25, 'Essential Denim Jacket - Light Blue Classic', '<p>M&ocirc; tả :</p>\r\n\r\n<p>- M&ocirc; tả sản phẩm: Relaxed Fit thiết kế dạng rộng<br />\r\n- Nơi sản xuất: Việt Nam<br />\r\n- Chất liệu: 100% cotton<br />\r\n- Hướng dẫn giặt ủi: Hạn chế tối đa bột giặt v&agrave; n&ecirc;n phơi gi&oacute; để giữ m&agrave;u bền l&acirc;u, lộn tr&aacute;i khi giặt v&agrave; để chế độ vắt nhẹ</p>\r\n', '650000.00', 0, 'dosiin-the-denimaniac-essential-denim-jacket-light-blue-classic-8454384543.jpg', '[\"dosiin-the-denimaniac-essential-denim-jacket-light-blue-classic-8454584545.jpg\"]', 1, 0, 4, 1, 1618167487),
(50, 25, 'Mayer Denim Jacket', '<p>M&ocirc; tả :</p>\r\n\r\n<p>- M&ocirc; tả sản phẩm: Mayer Denim Jacket<br />\r\n- Nơi sản xuất: Việt Nam<br />\r\n- Chất liệu: Denim<br />\r\n- Hướng dẫn giặt ủi: KH&Ocirc;NG GIẶT SẤY HOẶC GIẶT VỚI CHẤT TẨY MẠNH Ở NHIỆT ĐỘ CAO! Giặt nhẹ với nước lạnh v&agrave; một lượng nhỏ bột giặt.</p>\r\n', '480000.00', 0, 'dosiin_mayerclothing_DSCF8550_copy.jpg', '[]', 0, 0, 4, 1, 1618167623),
(51, 25, 'Button-Down Denim Overshirt - Mocha Grey', '<p>M&ocirc; tả :</p>\r\n\r\n<p>- M&ocirc; tả sản phẩm: Relaxed Fit thiết kế dạng rộng<br />\r\n- Nơi sản xuất: Việt Nam<br />\r\n- Chất liệu: 100% cotton<br />\r\n- Hướng dẫn giặt ủi: Hạn chế tối đa bột giặt v&agrave; n&ecirc;n phơi gi&oacute; để giữ m&agrave;u bền l&acirc;u, lộn tr&aacute;i khi giặt v&agrave; để chế độ vắt nhẹ</p>\r\n', '500000.00', 50000, 'dosiin-the-denimaniac-button-down-denim-overshirt-mocha-grey-7850178501.jpg', '[]', 1, 0, 4, 1, 1618167667),
(52, 25, 'The Laughter - LAUGHTERIAN PATTERN Jaket', '<p>M&ocirc; tả :</p>\r\n\r\n<p>- 100% Cotton, Decal phản quang, form oversize tay lỡ, hạn chế giặt m&aacute;y</p>\r\n', '700000.00', 100000, 'dosiin-the-laughter-streetwear-the-laughter-laughterian-pattern-jaket-105223105223.jpg', '[]', 1, 0, 9, 2, 1618167730),
(53, 25, 'Bloodmark Jacket', '<p>M&ocirc; tả :</p>\r\n\r\n<p>- Nơi sản xuất: Vietnam<br />\r\n- Colour: Light Grey<br />\r\n- Fabric: Polyeste / Acrylic / Quilted Cotton Lining</p>\r\n', '800000.00', 0, 'dosiin-guilty-child-bloodmark-jacket-104753104753.jpg', '[]', 0, 0, 4, 1, 1618167836),
(54, 10, 'INNERSECT - T-SHIRT - TRẮNG', '<p>M&ocirc; tả :</p>\r\n\r\n<p>- M&ocirc; tả sản phẩm: Tee Oversize - TRAM HỒNG<br />\r\n- Nơi sản xuất: Made in SaiGon by Ủn Ủn Meo Meo<br />\r\n- Chất liệu: Vải thun 100% cotton<br />\r\n- - Giặt bằng m&aacute;y giặt b&igrave;nh thường, ph&acirc;n loại c&aacute;c sản phẩm giặt. Kh&ocirc;ng ng&acirc;m v&agrave; đổ trực tiếp chất tẩy rửa l&ecirc;n &aacute;o.<br />\r\n- - Kh&ocirc;ng ủi trực tiếp l&ecirc;n h&igrave;nh in.<br />\r\n- - Để bảo quản sản phẩm l&acirc;u b&ecirc;n ch&uacute;ng t&ocirc;i khuyến kh&iacute;ch c&aacute;c bạn giặt bằng tay.<br />\r\n- - Hoặc c&aacute;c bạn hỏi c&aacute;ch giặt với c&aacute;c mẹ.</p>\r\n', '200000.00', 0, 'dosiin-kak-ao-thun-big-city-boy-sai-gon-likatrang-7134171341.jpg', '[]', 1, 0, 4, 1, 1618167929),
(55, 10, 'Tee Skull_Black', '<p>M&ocirc; tả :</p>\r\n\r\n<p>- Nơi sản xuất: Việt Nam<br />\r\n- Chất liệu: 100% Cotton cao cấp<br />\r\n- Hướng dẫn giặt ủi: B&igrave;nh thường</p>\r\n', '250000.00', 0, 'dosiin-way-tee-skull-black-7018170181.jpg', '[]', 1, 1, 4, 1, 1618168087),
(59, 29, 'Chân Váy Kẻ Caro Xẻ Tà Đai Chun Màu Wine ENVYLOOK Kevin Check Skirt', '<p>M&ocirc; tả :</p>\r\n\r\n<p>- M&ocirc; tả sản phẩm: Co d&atilde;n - tốt/ Xuy&ecirc;n thấu - kh&ocirc;ng/ D&agrave;y/ Độ mềm mại - trung b&igrave;nh/ Vải l&oacute;t - kh&ocirc;ng<br />\r\n- Nơi sản xuất: H&agrave;n Quốc<br />\r\n- Chất liệu: Cotton 100%<br />\r\n- Hướng dẫn giặt ủi: Giặt kh&ocirc;/ giặt tay<br />\r\n- Lưu &yacute;: K&iacute;ch thước bảng size b&ecirc;n dưới c&oacute; thể ch&ecirc;nh lệch 1-3cm t&ugrave;y v&agrave;o phương ph&aacute;p đo</p>\r\n', '350000.00', 0, 'dosiin-envylook-chan-vay-ke-caro-xe-ta-dai-chun-mau-wine-envylook-kevin-check-skirt-8955689556.jpg', '[]', 1, 0, 4, 1, 1618862226),
(66, 26, 'MULTI SNAP PANT/grey', '<p>M&ocirc; tả :</p>\r\n\r\n<p>- PRESENTED BY GOLDIE</p>\r\n', '750000.00', 0, 'dosiin-goldie-vietnam-multi-snap-pant-grey-5476154761.jpg', '[]', 0, 0, 4, 1, 1618863802),
(67, 26, 'Red-Blindness Pants', '<p>M&ocirc; tả :</p>\r\n\r\n<p>- Nơi sản xuất: Vietnam<br />\r\n- Form: Wide Leg</p>\r\n', '500000.00', 50000, 'dosiin-guilty-child-red-blindness-pant-103627103627.jpg', '[]', 0, 0, 4, 1, 1618863891),
(71, 26, 'FRINGE BUTTONED PANT', '<p>M&ocirc; tả :</p>\r\n\r\n<p>- M&ocirc; tả sản phẩm: Nơi sản xuất: Chất liệu: Hướng dẫn giặt ủi:</p>\r\n', '600000.00', 50000, 'dosiin-goldie-vietnam-fringe-buttoned-pant-5949059490.jpg', '[]', 1, 0, 4, 1, 1618864132);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `slider`
--

CREATE TABLE `slider` (
  `id` int(11) NOT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `image_link` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `link` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `sort_order` int(11) NOT NULL,
  `created` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `slider`
--

INSERT INTO `slider` (`id`, `name`, `image_link`, `link`, `sort_order`, `created`) VALUES
(12, '1', 'PC-ShopPage-fuonero-min.png', 'http://localhost/webshop/', 1, '2021-04-11 00:50:38'),
(14, '2', 'compressed-mj4q.png', 'http://localhost/webshop/', 2, '2021-04-11 00:54:05');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `transaction`
--

CREATE TABLE `transaction` (
  `id` int(11) NOT NULL,
  `status` int(11) NOT NULL DEFAULT 0,
  `user_id` int(11) NOT NULL DEFAULT 0,
  `user_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `user_email` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `user_phone` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `user_address` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `message` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `amount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `payment` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `created` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `transaction`
--

INSERT INTO `transaction` (`id`, `status`, `user_id`, `user_name`, `user_email`, `user_phone`, `user_address`, `message`, `amount`, `payment`, `created`) VALUES
(4, 1, 0, 'An Nhiên', 'annhien@gmail.com', '0166666666', 'Hoàng Mai - Hà Nội', 'Vui lòng trao hàng đến địa chỉ trên...', '350000.00', '', 1493983674),
(3, 1, 5, 'GoO', 'GoO@gmail.com', '01215345336', 'Hải Phòng', 'GUi hang den dia chi tren', '360000.00', '', 1493983674),
(5, 1, 0, 'Bình Nguyễn', 'binh@gmail.com', '0987654321', 'Hà Nội ', 'Gửi đến địa chỉ trên', '370000.00', '', 1494083674),
(6, 1, 0, 'Tô Nam', 'tonam@yahoo.com.vn', '098989876', 'Thủy Nguyên - Hải Phòng', 'Ship đến địa chỉ vào sáng ngày 23/5', '469000.00', '', 1494283674),
(7, 1, 5, 'GoO', 'GoO@gmail.com', '01215345336', 'Hải Phòng', 'Ship vào sáng mai.', '70000.00', '', 1494183674),
(8, 0, 0, 'Linh', 'ling@yahoo.com', '098798787', 'hai Phong', 'ship', '69000.00', '', 1494342674),
(9, 1, 0, 'Nhi', 'nhi@test.com', '0987654321', 'Long Biên - Hà Nội', 'Gửi hàng đến địa chỉ trên vào ngày mai', '200000.00', '', 1493983674),
(10, 0, 0, 'VIP User', 'test@gmail.com', '1234567890', 'Hải Phòng', 'Ship free', '450000.00', '', 1493983674),
(11, 0, 0, 'test', 'test@gmail.com', '1234567890', 'Hải Phòng', 'TESE', '300000.00', '', 1494383674),
(12, 0, 6, 'Nguyen An', 'khachhang1@gmail.com', '01201212222', 'Thủy Nguyên - Hải Phòng', 'SHIP TO', '169000.00', '', 1494407353),
(13, 1, 0, 'Lợi Nguyễn ', 'loinguyenqzz@gmail.com', '0343396322', 'Cầu Giấy', 'nice', '250000.00', '', 1618331718);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `user`
--

INSERT INTO `user` (`id`, `name`, `email`, `password`, `phone`, `address`, `created`) VALUES
(6, 'Nguyen An', 'khachhang1@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', '01201212222', 'Thủy Nguyên - Hải Phòng', 2147483647),
(5, 'User', 'user@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', '01215345336', 'Hải Phòng', 2147483647),
(7, 'TEST@gmail.com', 'TEST@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', '01215345336', 'Hải Phòng', 2017),
(8, 'loinguyen', 'new@gmail.com', '9446170b07587f40eee7f306783dd925', '01234456', 'Cầu Giấy', 2021);

--
-- Chỉ mục cho các bảng đã đổ
--

--
-- Chỉ mục cho bảng `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `catalog`
--
ALTER TABLE `catalog`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `order`
--
ALTER TABLE `order`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `slider`
--
ALTER TABLE `slider`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `transaction`
--
ALTER TABLE `transaction`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT cho các bảng đã đổ
--

--
-- AUTO_INCREMENT cho bảng `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT cho bảng `catalog`
--
ALTER TABLE `catalog`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT cho bảng `order`
--
ALTER TABLE `order`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT cho bảng `product`
--
ALTER TABLE `product`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=73;

--
-- AUTO_INCREMENT cho bảng `slider`
--
ALTER TABLE `slider`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT cho bảng `transaction`
--
ALTER TABLE `transaction`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT cho bảng `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
