<div class="row" >
			<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12" id="bank">
				<div class="col-xs-12 col-sm-8 col-md-8 col-lg-8 no-padding">
				    <div class="footer-info">            
				      <div class="col-xs-12 col-sm-4 col-md-4 col-lg-4">
				        <a href="" title=""><strong>VỀ CHÚNG TÔI</strong></a>
				          <li> <a href="#" title="">Giới thiệu về shop</a></li> 
				          <li> <a href="#" title="">Các mức chế tài vi phạm</a></li> 
				          <li> <a href="#" title="">Quy chế hoạt động</a></li> 
				      </div>
				      <div class="col-xs-12 col-sm-4 col-md-4 col-lg-4">
				        <a href="" title=""><strong>DÀNH CHO NGƯỜI MUA</strong></a>
				          <li> <a href="#" title="">Bảo vệ người mua</a></li>
				          <li> <a href="#" title="">Quy định đối với người mua</a></li>
				          <li> <a href="#" title="">Câu hỏi thường gặp</a></li>
				          <li> <a href="#" title="">Hưỡng dẫn mua hàng Online</a></li> 
				           
				      </div>
				      <div class="col-xs-12 col-sm-4 col-md-4 col-lg-4">
				        <a href="" title=""><strong>DÀNH CHO NGƯỜI BÁN</strong></a>                
				          <li> <a href="#" title="">Mở shop trên Sendo</a></li> 
				          <li> <a href="#" title="">Quy định đối với người bán</a></li> 
				          <li> <a href="#" title="">Chính sách bán hàng</a></li> 
				      </div>
				    </div>
				</div>
				<div class="col-xs-12 col-sm-4 col-md-4 col-lg-4">
				    <p>Hỗ trợ thanh toán  <img src="http://localhost/myshop/public/images/pay.png" alt="" style="padding-left: 25px;"> </p>
				    <div class="fi-left pull-left">
				      <p><small>Tư vẫn miễn phí (24/7)</small></p> 
				      <strong>1800 3333</strong>
				    </div>
				     <div class="fi-right pull-right">
				      <p><small>Góp ý, phản ánh(8h00 - 22h00)</small></p>
				      <strong>1800 3333</strong>
				    </div>
				  </div>
			</div>
		</div>
		<div class="row" id="footer">
			<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
				<div class="col-xs-12 col-sm-8 col-md-8 col-lg-8">
					<address>
					  <strong>    SHOP thời trang Z</strong><br>
					  <span class="glyphicon glyphicon-home" aria-hidden="true"></span> Địa chỉ: 144 Xuân Thủy - Cầu Giấu - Hà Nội<br>
					  <span class="glyphicon glyphicon-phone" aria-hidden="true"></span> Điện thoại: 0123456789<br>
					  Copyright ©2021 - Design by Z
					</address>
				</div>
				<div class="col-xs-12 col-sm-4 col-md-4 col-lg-4 text-right">
					<a href="#"><img src="<?php echo base_url(); ?>upload/icon/facebook.png" alt=""></a>
					<a href="#"><img src="<?php echo base_url(); ?>upload/icon/twitter.png" alt=""></a>
					<a href="#"><img src="<?php echo base_url(); ?>upload/icon/google.png" alt=""></a>
				</div>
				<div class="clearfix"></div>
			</div>
		</div>