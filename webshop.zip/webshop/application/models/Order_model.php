<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Order_model extends MY_Model {
	var $table = 'order';
}